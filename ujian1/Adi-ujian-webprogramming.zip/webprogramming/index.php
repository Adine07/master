<?php 

header('location:category/index.php');
 ?>
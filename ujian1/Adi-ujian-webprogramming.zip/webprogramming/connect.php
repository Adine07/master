<?php

$server = "localhost";
$user = "root";
$passwd = "anda";
$db = "point_of_sale";

$connect = mysqli_connect($server,$user,$passwd,$db);

?>